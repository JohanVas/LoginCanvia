package com.cristhiandev.loginproject.data

import android.app.Application

class LoginRepository(var application: Application) {

    var callback: RetrofitCallback = RetrofitCallback()

    class RetrofitCallback {

    }
}
