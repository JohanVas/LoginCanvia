package com.cristhiandev.loginproject.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData

class ViewModel(application: Application) : AndroidViewModel(application) {

    lateinit var username: MutableLiveData<String>
    lateinit var password: MutableLiveData<String>

    fun onLoginBtnCLicked() {
        initiateOTP()
    }

    private fun initiateOTP() {
        TODO("Not yet implemented")
    }
}